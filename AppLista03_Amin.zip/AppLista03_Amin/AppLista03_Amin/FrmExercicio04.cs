﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Amin
{
    public partial class FrmExercicio04 : Form
    {
        public FrmExercicio04()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float v1, v2, resultado;
            v1 = float.Parse(txtnum.Text);
            v2 = float.Parse(txtvalorpreço.Text);
            resultado = v1 * v2;
            lblarea.Text = resultado.ToString();
        }

        private void FrmExercicio04_Load(object sender, EventArgs e)
        {

        }
    }
}
