﻿namespace AppLista03_Amin
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtvalorpreço = new System.Windows.Forms.TextBox();
            this.lblpreco = new System.Windows.Forms.Label();
            this.ls = new System.Windows.Forms.Label();
            this.ll = new System.Windows.Forms.Label();
            this.txtnum = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 23);
            this.label2.TabIndex = 16;
            this.label2.Text = "Valor do Kg:";
            // 
            // txtvalorpreço
            // 
            this.txtvalorpreço.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtvalorpreço.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalorpreço.Location = new System.Drawing.Point(273, 117);
            this.txtvalorpreço.Name = "txtvalorpreço";
            this.txtvalorpreço.Size = new System.Drawing.Size(255, 34);
            this.txtvalorpreço.TabIndex = 15;
            // 
            // lblpreco
            // 
            this.lblpreco.AutoSize = true;
            this.lblpreco.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreco.Location = new System.Drawing.Point(215, 289);
            this.lblpreco.Name = "lblpreco";
            this.lblpreco.Size = new System.Drawing.Size(0, 23);
            this.lblpreco.TabIndex = 14;
            // 
            // ls
            // 
            this.ls.AutoSize = true;
            this.ls.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ls.Location = new System.Drawing.Point(30, 289);
            this.ls.Name = "ls";
            this.ls.Size = new System.Drawing.Size(151, 17);
            this.ls.TabIndex = 13;
            this.ls.Text = "Dinheiro a pagar:";
            // 
            // ll
            // 
            this.ll.AutoSize = true;
            this.ll.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ll.Location = new System.Drawing.Point(29, 63);
            this.ll.Name = "ll";
            this.ll.Size = new System.Drawing.Size(186, 23);
            this.ll.TabIndex = 12;
            this.ll.Text = "Peso da comida:";
            // 
            // txtnum
            // 
            this.txtnum.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtnum.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum.Location = new System.Drawing.Point(273, 63);
            this.txtnum.Name = "txtnum";
            this.txtnum.Size = new System.Drawing.Size(255, 34);
            this.txtnum.TabIndex = 11;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(404, 186);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 57);
            this.button2.TabIndex = 10;
            this.button2.Text = "Enter";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(613, 380);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtvalorpreço);
            this.Controls.Add(this.lblpreco);
            this.Controls.Add(this.ls);
            this.Controls.Add(this.ll);
            this.Controls.Add(this.txtnum);
            this.Controls.Add(this.button2);
            this.Name = "FrmExercicio03";
            this.Text = "exercicio1";
            this.Load += new System.EventHandler(this.FrmExercicio01_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtvalorpreço;
        private System.Windows.Forms.Label lblpreco;
        private System.Windows.Forms.Label ls;
        private System.Windows.Forms.Label ll;
        private System.Windows.Forms.TextBox txtnum;
        private System.Windows.Forms.Button button2;
    }
}

