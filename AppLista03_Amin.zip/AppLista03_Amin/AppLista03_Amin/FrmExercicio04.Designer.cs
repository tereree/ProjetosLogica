﻿namespace AppLista03_Amin
{
    partial class FrmExercicio04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtvalorpreço = new System.Windows.Forms.TextBox();
            this.lblarea = new System.Windows.Forms.Label();
            this.ls = new System.Windows.Forms.Label();
            this.ll = new System.Windows.Forms.Label();
            this.txtnum = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 23);
            this.label2.TabIndex = 23;
            this.label2.Text = "Lado2";
            // 
            // txtvalorpreço
            // 
            this.txtvalorpreço.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtvalorpreço.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvalorpreço.Location = new System.Drawing.Point(123, 116);
            this.txtvalorpreço.Name = "txtvalorpreço";
            this.txtvalorpreço.Size = new System.Drawing.Size(255, 34);
            this.txtvalorpreço.TabIndex = 22;
            // 
            // lblarea
            // 
            this.lblarea.AutoSize = true;
            this.lblarea.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblarea.Location = new System.Drawing.Point(219, 206);
            this.lblarea.Name = "lblarea";
            this.lblarea.Size = new System.Drawing.Size(0, 23);
            this.lblarea.TabIndex = 21;
            // 
            // ls
            // 
            this.ls.AutoSize = true;
            this.ls.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ls.Location = new System.Drawing.Point(151, 206);
            this.ls.Name = "ls";
            this.ls.Size = new System.Drawing.Size(49, 17);
            this.ls.TabIndex = 20;
            this.ls.Text = "Área:";
            // 
            // ll
            // 
            this.ll.AutoSize = true;
            this.ll.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ll.Location = new System.Drawing.Point(22, 73);
            this.ll.Name = "ll";
            this.ll.Size = new System.Drawing.Size(80, 23);
            this.ll.TabIndex = 19;
            this.ll.Text = "Lado1:";
            // 
            // txtnum
            // 
            this.txtnum.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtnum.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum.Location = new System.Drawing.Point(123, 62);
            this.txtnum.Name = "txtnum";
            this.txtnum.Size = new System.Drawing.Size(255, 34);
            this.txtnum.TabIndex = 18;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(26, 184);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 57);
            this.button2.TabIndex = 17;
            this.button2.Text = "Enter";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FrmExercicio04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(507, 310);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtvalorpreço);
            this.Controls.Add(this.lblarea);
            this.Controls.Add(this.ls);
            this.Controls.Add(this.ll);
            this.Controls.Add(this.txtnum);
            this.Controls.Add(this.button2);
            this.Name = "FrmExercicio04";
            this.Text = "FrmExercicio04";
            this.Load += new System.EventHandler(this.FrmExercicio04_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtvalorpreço;
        private System.Windows.Forms.Label lblarea;
        private System.Windows.Forms.Label ls;
        private System.Windows.Forms.Label ll;
        private System.Windows.Forms.TextBox txtnum;
        private System.Windows.Forms.Button button2;
    }
}