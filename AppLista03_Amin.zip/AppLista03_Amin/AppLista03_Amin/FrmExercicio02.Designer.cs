﻿namespace AppLista03_Amin
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtgaso = new System.Windows.Forms.TextBox();
            this.lblpreco = new System.Windows.Forms.Label();
            this.ls = new System.Windows.Forms.Label();
            this.ll = new System.Windows.Forms.Label();
            this.txtnum = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 23);
            this.label1.TabIndex = 21;
            this.label1.Text = "Valor gasolina:";
            // 
            // txtgaso
            // 
            this.txtgaso.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtgaso.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgaso.Location = new System.Drawing.Point(281, 173);
            this.txtgaso.Name = "txtgaso";
            this.txtgaso.Size = new System.Drawing.Size(258, 34);
            this.txtgaso.TabIndex = 20;
            // 
            // lblpreco
            // 
            this.lblpreco.AutoSize = true;
            this.lblpreco.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpreco.Location = new System.Drawing.Point(187, 281);
            this.lblpreco.Name = "lblpreco";
            this.lblpreco.Size = new System.Drawing.Size(0, 23);
            this.lblpreco.TabIndex = 19;
            // 
            // ls
            // 
            this.ls.AutoSize = true;
            this.ls.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ls.Location = new System.Drawing.Point(12, 287);
            this.ls.Name = "ls";
            this.ls.Size = new System.Drawing.Size(169, 17);
            this.ls.TabIndex = 18;
            this.ls.Text = "Litros abastecidos:";
            // 
            // ll
            // 
            this.ll.AutoSize = true;
            this.ll.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ll.Location = new System.Drawing.Point(124, 108);
            this.ll.Name = "ll";
            this.ll.Size = new System.Drawing.Size(118, 23);
            this.ll.TabIndex = 17;
            this.ll.Text = "Dinheiro:";
            // 
            // txtnum
            // 
            this.txtnum.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtnum.Font = new System.Drawing.Font("Arial Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum.Location = new System.Drawing.Point(281, 103);
            this.txtnum.Name = "txtnum";
            this.txtnum.Size = new System.Drawing.Size(258, 34);
            this.txtnum.TabIndex = 16;
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn1.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(395, 287);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(103, 60);
            this.btn1.TabIndex = 15;
            this.btn1.Text = "Enter";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click_1);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(564, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtgaso);
            this.Controls.Add(this.lblpreco);
            this.Controls.Add(this.ls);
            this.Controls.Add(this.ll);
            this.Controls.Add(this.txtnum);
            this.Controls.Add(this.btn1);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtgaso;
        private System.Windows.Forms.Label lblpreco;
        private System.Windows.Forms.Label ls;
        private System.Windows.Forms.Label ll;
        private System.Windows.Forms.TextBox txtnum;
        private System.Windows.Forms.Button btn1;
    }
}